# Ominull Windows Agent Unattended Installer
param(
    [string]$HubURL = "https://omi.summitflow.dev",
    [string]$APIKey = "omi_live_master",
    [string]$Role = "workstation",
    [string]$Location = "loc-home"
)
$InstallDir = "C:\Program Files\Ominull"
New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
Copy-Item ".\ominulld.exe" -Destination "$InstallDir\ominulld.exe" -Force

# Register Windows Service
sc.exe stop OminullAgent 2>$null | Out-Null
sc.exe delete OminullAgent 2>$null | Out-Null
sc.exe create OminullAgent binPath= "\"$InstallDir\ominulld.exe\" --hub $HubURL --key $APIKey --role $Role --location $Location" start= auto DisplayName= "Ominull Threat Nullification Service"
sc.exe start OminullAgent
Write-Host "[+] Ominull Windows Agent installed and started successfully!" -ForegroundColor Green
